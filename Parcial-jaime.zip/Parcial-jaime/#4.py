#Implemente un programa que use try–except para:
#1. Pedir al usuario dos números enteros.
#2. Calcular la división entre ellos.
#3. Si el usuario ingresa un valor no numérico → mostrar "Error: Debe ingresar
#   números enteros".
#4. Si intenta dividir entre cero → mostrar "Error: No se puede dividir entre
#   cero".
def dividir_numeros():
    try:
        num1 = int(input("Ingrese el primer número entero: "))
        num2 = int(input("Ingrese el segundo número entero: "))
        
        resultado = num1 / num2
        print(f"El resultado de {num1} dividido entre {num2} es: {resultado}")
        
    except ValueError:
        print("Error: Debe ingresar números enteros.")
    except ZeroDivisionError:
        print("Error: No se puede dividir entre cero.")
# Llamamos a la función para ejecutar el programa
dividir_numeros()

    